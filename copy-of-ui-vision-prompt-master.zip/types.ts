
export interface DesignAnalysis {
  colors: string[];
  atmosphere: string;
  style: string;
  layout: string;
  typography: string;
  elements: string[];
  generatedPrompt: string;
  shortPrompt: string;
}

export enum AnalysisStatus {
  IDLE = 'IDLE',
  LOADING = 'LOADING',
  SUCCESS = 'SUCCESS',
  ERROR = 'ERROR'
}
