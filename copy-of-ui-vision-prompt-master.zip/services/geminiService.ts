
import { GoogleGenAI, Type } from "@google/genai";
import { DesignAnalysis } from "../types";

export const extractDesignFromImage = async (base64Image: string): Promise<DesignAnalysis> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const prompt = `
    あなたは世界クラスのUI/UXデザイナーであり、AI画像生成（Midjourney, DALL-E 3, Stable Diffusionなど）のためのエキスパート・プロンプトエンジニアです。
    このUIスクリーンショットを詳細に解析し、以下の仕様を抽出してください。
    
    【重要】解析結果（雰囲気、スタイル、レイアウト、タイポグラフィ、要素）は日本語で回答してください。
    ただし、生成される「generatedPrompt」と「shortPrompt」は、海外のAIツールでの利用を想定し、英語で出力してください。

    1. カラーパレット: プライマリ、セカンダリ、アクセントカラーを16進数コードで特定。
    2. 雰囲気 (Atmosphere): 視覚的なムード（例：プロフェッショナル、遊び心がある、未来的、ミニマルなど）。
    3. スタイル (Style): UIデザインのトレンド（例：ニューモーフィズム、グラスモーフィズム、マテリアルデザイン、フラット 2.0など）。
    4. レイアウト (Layout): 構造的な構成（例：12カラムグリッド、サイドバーナビゲーション、マテリアルグリッドなど）。
    5. タイポグラフィ (Typography): フォントの特徴（例：幾何学的サンセリフ、高コントラストなセリフ体、行間など）。
    6. 要素 (Elements): 表示されている主要なUIコンポーネント（例：カード、ガラス風ボタン、チャート、アバターなど）。
    
    最後に、2つの高品質なプロンプト（英語）を生成してください：
    - generatedPrompt: このUIの本質を捉え、高精度に再現するための詳細で記述的なプロンプト。
    - shortPrompt: 素早い試行錯誤のために最適化された、短く簡潔なプロンプト。
    
    結果は厳密にJSON形式で返してください。
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [
        {
          parts: [
            { text: prompt },
            {
              inlineData: {
                mimeType: 'image/png',
                data: base64Image.split(',')[1] || base64Image,
              },
            },
          ],
        },
      ],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            colors: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "カラーコードの配列"
            },
            atmosphere: { type: Type.STRING },
            style: { type: Type.STRING },
            layout: { type: Type.STRING },
            typography: { type: Type.STRING },
            elements: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            generatedPrompt: { type: Type.STRING },
            shortPrompt: { type: Type.STRING },
          },
          required: ["colors", "atmosphere", "style", "layout", "typography", "elements", "generatedPrompt", "shortPrompt"],
        },
      },
    });

    const result = JSON.parse(response.text || '{}');
    return result as DesignAnalysis;
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    throw new Error("画像の解析に失敗しました。もう一度お試しください。");
  }
};
