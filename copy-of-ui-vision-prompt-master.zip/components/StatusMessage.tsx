
import React from 'react';

interface StatusMessageProps {
  type: 'loading' | 'error';
  message: string;
}

const StatusMessage: React.FC<StatusMessageProps> = ({ type, message }) => {
  const isError = type === 'error';
  
  return (
    <div className={`mt-8 p-4 rounded-xl flex items-center gap-3 ${isError ? 'bg-red-900/20 border border-red-500/50 text-red-200' : 'bg-blue-900/10 border border-blue-500/30 text-blue-200'}`}>
      {type === 'loading' && (
        <div className="w-5 h-5 border-2 border-blue-400 border-t-transparent rounded-full animate-spin" />
      )}
      {isError && (
        <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6 text-red-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      )}
      <p className="font-medium">{message}</p>
    </div>
  );
};

export default StatusMessage;
