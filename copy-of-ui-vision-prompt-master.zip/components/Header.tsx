
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="py-8 text-center">
      <h1 className="text-4xl md:text-5xl font-bold mb-3 gradient-text">
        UI Vision Prompt Master
      </h1>
      <p className="text-gray-400 text-lg max-w-2xl mx-auto px-4">
        UIのスクリーンショットからデザインのDNAを抽出し、画像生成AI用の最適化プロンプトを作成します。
      </p>
    </header>
  );
};

export default Header;
