
import React, { useState, useRef } from 'react';
import Header from './components/Header';
import StatusMessage from './components/StatusMessage';
import { extractDesignFromImage } from './services/geminiService';
import { DesignAnalysis, AnalysisStatus } from './types';

const App: React.FC = () => {
  const [image, setImage] = useState<string | null>(null);
  const [status, setStatus] = useState<AnalysisStatus>(AnalysisStatus.IDLE);
  const [result, setResult] = useState<DesignAnalysis | null>(null);
  const [errorMessage, setErrorMessage] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
        setResult(null);
        setStatus(AnalysisStatus.IDLE);
      };
      reader.readAsDataURL(file);
    }
  };

  const analyzeImage = async () => {
    if (!image) return;
    
    setStatus(AnalysisStatus.LOADING);
    setErrorMessage('');
    
    try {
      const analysis = await extractDesignFromImage(image);
      setResult(analysis);
      setStatus(AnalysisStatus.SUCCESS);
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : '予期せぬエラーが発生しました');
      setStatus(AnalysisStatus.ERROR);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    alert('プロンプトをクリップボードにコピーしました！');
  };

  return (
    <div className="min-h-screen pb-20 px-4 md:px-8">
      <Header />

      <main className="max-w-6xl mx-auto space-y-12">
        {/* アップロードセクション */}
        <section className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="glass p-6 rounded-3xl flex flex-col h-full">
            <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
              <span className="p-2 bg-blue-500/20 rounded-lg">📸</span>
              1. 画像をアップロード
            </h2>
            
            <div className="flex-grow flex flex-col items-center justify-center border-2 border-dashed border-gray-700 rounded-2xl p-8 hover:border-blue-500/50 transition-colors cursor-pointer" onClick={() => fileInputRef.current?.click()}>
              {image ? (
                <div className="relative w-full aspect-video rounded-lg overflow-hidden group">
                  <img src={image} alt="プレビュー" className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                    <span className="text-white font-medium">画像を変更する</span>
                  </div>
                </div>
              ) : (
                <div className="text-center">
                  <div className="text-5xl mb-4">🖼️</div>
                  <p className="text-gray-400 font-medium">クリックして画像を選択、またはドラッグ＆ドロップ</p>
                  <p className="text-xs text-gray-500 mt-2">PNG, JPG 対応（UIのスクリーンショットを推奨）</p>
                </div>
              )}
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleFileChange} 
                className="hidden" 
                accept="image/*" 
              />
            </div>

            <button
              onClick={analyzeImage}
              disabled={!image || status === AnalysisStatus.LOADING}
              className={`mt-6 w-full py-4 rounded-xl font-bold text-white transition-all shadow-lg ${
                !image || status === AnalysisStatus.LOADING 
                ? 'bg-gray-800 cursor-not-allowed text-gray-500' 
                : 'bg-gradient-to-r from-blue-600 to-purple-600 hover:scale-[1.02] active:scale-[0.98]'
              }`}
            >
              {status === AnalysisStatus.LOADING ? '解析中...' : 'デザイン解析とプロンプト生成を開始'}
            </button>
          </div>

          <div className="glass p-6 rounded-3xl flex flex-col h-full">
            <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
              <span className="p-2 bg-purple-500/20 rounded-lg">🎨</span>
              2. 抽出されたデザイン要素
            </h2>
            
            {status === AnalysisStatus.SUCCESS && result ? (
              <div className="space-y-6 overflow-y-auto max-h-[500px] pr-2 custom-scrollbar">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="bg-white/5 p-4 rounded-xl">
                    <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">カラーパレット</h3>
                    <div className="flex flex-wrap gap-2">
                      {result.colors.map((color, i) => (
                        <div key={i} className="flex items-center gap-1.5 bg-black/30 p-1 pr-2 rounded-lg border border-white/10">
                          <div className="w-4 h-4 rounded" style={{ backgroundColor: color }}></div>
                          <span className="text-[10px] font-mono text-gray-300">{color}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="bg-white/5 p-4 rounded-xl">
                    <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">雰囲気・ムード</h3>
                    <p className="text-sm text-gray-300">{result.atmosphere}</p>
                  </div>
                </div>

                <div className="bg-white/5 p-4 rounded-xl">
                  <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">デザインスタイル</h3>
                  <p className="text-sm text-gray-300">{result.style}</p>
                </div>

                <div className="bg-white/5 p-4 rounded-xl">
                  <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">レイアウト構成</h3>
                  <p className="text-sm text-gray-300">{result.layout}</p>
                </div>

                <div className="bg-white/5 p-4 rounded-xl">
                  <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">タイポグラフィ</h3>
                  <p className="text-sm text-gray-300">{result.typography}</p>
                </div>

                <div className="bg-white/5 p-4 rounded-xl">
                  <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">主要な要素</h3>
                  <div className="flex flex-wrap gap-2">
                    {result.elements.map((el, i) => (
                      <span key={i} className="text-xs bg-purple-500/10 text-purple-300 px-2 py-1 rounded border border-purple-500/20">{el}</span>
                    ))}
                  </div>
                </div>
              </div>
            ) : status === AnalysisStatus.LOADING ? (
              <div className="flex-grow flex items-center justify-center text-gray-500 italic">
                デザインパターンを解読中...
              </div>
            ) : (
              <div className="flex-grow flex items-center justify-center text-gray-600">
                画像を解析すると、ここにデザイン要素が表示されます。
              </div>
            )}
          </div>
        </section>

        {/* ステータスメッセージ */}
        {status === AnalysisStatus.LOADING && (
          <StatusMessage type="loading" message="AIがUIコンポーネントを分析し、プロンプトを構築しています..." />
        )}
        {status === AnalysisStatus.ERROR && (
          <StatusMessage type="error" message={errorMessage} />
        )}

        {/* 最終プロンプトセクション */}
        {status === AnalysisStatus.SUCCESS && result && (
          <section className="glass p-8 rounded-3xl animate-in fade-in slide-in-from-bottom-4 duration-700">
            <h2 className="text-2xl font-bold mb-8 flex items-center gap-3">
              <span className="p-3 bg-green-500/20 rounded-2xl">✨</span>
              生成されたAIプロンプト
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* 詳細プロンプト */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-blue-400 uppercase tracking-widest">詳細な生成用プロンプト (英語)</h3>
                  <button 
                    onClick={() => copyToClipboard(result.generatedPrompt)}
                    className="text-xs bg-white/10 hover:bg-white/20 transition-colors px-3 py-1.5 rounded-lg flex items-center gap-2"
                  >
                    <span>📋</span> コピー
                  </button>
                </div>
                <div className="bg-black/40 border border-white/5 rounded-2xl p-6 text-gray-300 text-sm leading-relaxed whitespace-pre-wrap min-h-[160px]">
                  {result.generatedPrompt}
                </div>
              </div>

              {/* 短縮プロンプト */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-purple-400 uppercase tracking-widest">短縮・即戦力プロンプト (英語)</h3>
                  <button 
                    onClick={() => copyToClipboard(result.shortPrompt)}
                    className="text-xs bg-white/10 hover:bg-white/20 transition-colors px-3 py-1.5 rounded-lg flex items-center gap-2"
                  >
                    <span>📋</span> コピー
                  </button>
                </div>
                <div className="bg-black/40 border border-white/5 rounded-2xl p-6 text-gray-300 text-sm leading-relaxed whitespace-pre-wrap min-h-[160px]">
                  {result.shortPrompt}
                </div>
              </div>
            </div>

            <div className="mt-8 pt-8 border-t border-white/5">
              <p className="text-xs text-center text-gray-500">
                以下のツールに最適化されています：
                <span className="mx-2 text-gray-400">Midjourney v6</span> • 
                <span className="mx-2 text-gray-400">v0.dev</span> • 
                <span className="mx-2 text-gray-400">DALL-E 3</span> • 
                <span className="mx-2 text-gray-400">Stable Diffusion 3</span>
              </p>
            </div>
          </section>
        )}
      </main>

      <footer className="fixed bottom-0 left-0 right-0 py-4 px-8 glass border-t border-white/10 flex justify-center z-50">
        <p className="text-xs text-gray-500">
          Gemini 3 Flash を使用した瞬時のビジュアル解析
        </p>
      </footer>
    </div>
  );
};

export default App;
