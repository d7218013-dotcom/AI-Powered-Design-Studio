
// This component has been replaced by BottomNav.tsx
export {};
